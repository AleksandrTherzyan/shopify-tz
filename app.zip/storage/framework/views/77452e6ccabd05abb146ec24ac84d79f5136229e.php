<?php $__env->startSection('content'); ?>

    <h1>
        Test
    </h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/lrogiixt/public_html/shopify-tz/resources/views/workshop.blade.php ENDPATH**/ ?>