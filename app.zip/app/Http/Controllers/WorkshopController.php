<?php


namespace App\Http\Controllers;


class WorkshopController extends Controller
{
    
    
    public function index()
    {
        
        
        return view('workshop');
    }
    

}